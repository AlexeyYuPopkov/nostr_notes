import json
import re
import pymorphy3

_morph = pymorphy3.MorphAnalyzer()


def lemmatize(word: str) -> str:
    """Приводит слово к лемме (начальной форме).
    passwords -> password, keys -> key, notes -> note и т.д."""
    parsed = _morph.parse(word)
    best = parsed[0] if parsed else None
    # pymorphy3 хорошо работает с русским — используем если слово не латиница
    if best and 'LATN' not in best.tag:
        return best.normal_form
    # Фоллбэк для английских слов: простое снятие множественного числа
    if word.endswith('sses'):
        return word[:-2]       # passes -> pass
    if word.endswith('ies'):
        return word[:-3] + 'y' # entries -> entry
    if word.endswith('ses') or word.endswith('zes') or word.endswith('xes'):
        return word[:-2]       # boxes -> box
    if word.endswith('s') and not word.endswith('ss'):
        return word[:-1]       # keys -> key, passwords -> password
    return word


def load_train_data(json_path: str):
    """Загружает данные из JSON и автоматически строит маппинг классов."""
    with open(json_path, encoding="utf-8") as f:
        raw = json.load(f)

    # Разбиваем по любым разделителям: пробел, таб, запятая, точка, точка с запятой и т.п.
    def split_classes(s: str) -> list[str]:
        return [lemmatize(c.lower()) for c in re.split(r'[\s,\.;:]+', s) if c]

    keys = set()
    for item in raw:
        keys.update(split_classes(item["class"]))
    all_classes = sorted(keys)
    class_to_idx = {cls: idx for idx, cls in enumerate(all_classes)}

    train_data = [
        (item["text"], [class_to_idx[cls] for cls in split_classes(item["class"])])
        for item in raw
    ]
    
    return train_data, all_classes